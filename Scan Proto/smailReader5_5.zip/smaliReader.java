import java.io.*;
import java.util.*;
import java.lang.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class smaliReader
{
	ArrayList readF;
	ArrayList trace;
	
	String 

	public smaliReader(File currentFile)
	{
		//Read in the file
		BufferedReader reader;
		readF = new ArrayList();
		trace = new ArrayList();
		
		try {
            reader = new BufferedReader(new FileReader(currentFile));
        
			String line = null;
			
            line = reader.readLine();
       
			while (line != null)
			{
				readF.add(line);
				
				line = reader.readLine();
				
			}
		
		} catch(IOException fnfe3) { 
				System.out.println(fnfe3.getMessage());
		}
	}
	
	public smaliReader(File currentFile. int lineNumber, String keyword)
	
	public String startTrace(String keyword, int lineNumber)
	{
		String result="";
		System.out.println("Starting trace");
		
		String tmp = readF.get(lineNumber).toString();
				
		int searchLine = lineNumber +1;
		String storedVar=getStoredVarible(tmp);
		
		while(tmp.contains(".end method")==false)
		{	
				
			if(tmp.contains(".method"))
			{
				tmp = readF.get(searchLine).toString();
								
				boolean first = true;
				while(first)
				{
					tmp = tmp.trim();
					
					if(tmp.matches(".local\\s(.*)") && first)
					{
						storedVar = getStoredVarible(tmp);
						System.out.println("Passed varible stored in "+storedVar);
						trace.add(tmp);
						first = false;
						//break;
						//
					}
					searchLine++;
					tmp = readF.get(searchLine).toString();
				}
				
			}
			else if(tmp.contains("invoke-") || tmp.contains("move-result-object") || tmp.contains("return-object"))
			{
				
				tmp = readF.get(searchLine).toString();
				String nextInstance="";
					
				
				String noReturnType = tmp.replaceAll("\\(\\S+","");
								
				if(noReturnType.contains("Lorg/apache/") || noReturnType.contains("Ljava/") || tmp.contains("move-result")||tmp.contains("return-object"))
				{
					
					if( tmp.contains(storedVar) && tmp.contains("return-object"))
					{
						System.out.println("Varible is returned by method");
						result = findMethodName(lineNumber);
						result = "->"+result;
						trace.add(tmp);
						return result;
						
					}
					else if ((lineNumber + 2)==searchLine && tmp.contains("move-result"))
					{	
						storedVar = getStoredVarible(tmp);
						System.out.println("value now stored in " + storedVar);
						trace.add(tmp);
					}
					else if (tmp.contains(storedVar))
					{
						storedVar = getStoredVarible(tmp);
						System.out.println("Varible is now stored in " + storedVar);
						trace.add(tmp);
					}
				}
				else if(tmp.contains(storedVar))
				{
					
					result = extractMethodName(tmp);
					result=".method(.*)"+result+"\\S+";
					trace.add(tmp);
					
					return result;
				}
						
				
			}
			searchLine++;
			tmp = readF.get(searchLine).toString();
		
		}
		result="End of method reached";
		return result;
	}
	
	public String extractMethodName(String tmp)
	{
		Pattern p = Pattern.compile("(?<=->)\\S+(?=\\()");
		Matcher m = p.matcher(tmp);
		int count = 0;
		if(m.find())
		{
			tmp = tmp.substring(m.start(), m.end());
		}
		
		return tmp;
	}
	
		
	public String findMethodName(int lineNumber)
	{
		String found="";
		
		for(int j=lineNumber; j>0; j--)
		{
			String tmp2 = readF.get(j).toString();
			
			if(tmp2.contains("method"))
			{
				String[] methNames = tmp2.split(" ");
										
				for (String a : methNames)
				{
					if (a.contains("("))
					{
						int endMethName = a.indexOf("(");
						String methName = a.substring(0, endMethName);
						System.out.println("Method called in: "+methName);
						return methName;
			
					}
				}
				return tmp2;

			
			}
			
		}
		return found;
	}
	
	public String getStoredVarible(String tmp)
	{
		tmp = tmp.trim();
		String[] elements = tmp.split(" ");
		String a = elements[1].replace("{", "").replace(",", "").replace("}", "");
					
		return a;
	}
	
	public String findKeyword(String keyword)
	{
		String result="";
				
		for(int i=0; i<readF.size(); i++)
		{
			
			String tmp = readF.get(i).toString();
			if(tmp.contains(keyword)|| tmp.matches(keyword) )
			{
				System.out.println(keyword+" accessed");
				trace.add(tmp);
				result = startTrace(keyword, i);
				return result;
			}
		}
		return result;
	}
	
	public ArrayList getTraceLog()
	{
		return trace;
	}
	
}


