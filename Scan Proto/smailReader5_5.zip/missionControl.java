import java.io.File;
import java.util.*;
import java.lang.*;

public class missionControl
{
	
	public static void main(String [] args)
	{
		ArrayList traceLog = new ArrayList();
		fileTraversal jill = new fileTraversal("C:\\Users\\Kanesol\\Dropbox\\Malware Samples\\smali\\");
		ArrayList files = jill.getPaths();
		smaliReader reader;
		String result = "";
		String search = "->getDeviceId";
		File bob;
		
		for(int i=0; i< files.size(); i++)
		{
			bob = new File(files.get(i).toString());
			reader = new smaliReader(bob);
			result = reader.findKeyword(search);
			
			if(result.compareTo("")!=0)
			{
				search=result;
			
				search = result;
				traceLog.add(reader.getTraceLog());
				result="";
				i=0;
				
			}
			//traceLog.add(reader.getTraceLog());
		}
		//System.out.println(result);
		
		ArrayList log = (ArrayList)traceLog.get(traceLog.size()-1);
		//for(int i=0; i< log.size(); i++)
		//{
			System.out.println("Final call at: "+log.get(log.size()-1));
		//	}

		
	}
	
	private static String getMethodName(String methodString)
	{
		String[] methNames = methodString.split(" ");
										
		for (String a : methNames)
		{
			if (a.contains("("))
			{
				int endMethName = a.indexOf("(");
				String methName = a.substring(0, endMethName);
				
				return methName;
				
			}
		}
		return "";
	}

} 