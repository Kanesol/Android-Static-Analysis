import java.io.*;
import java.util.*;
import java.lang.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class smaliReader
{
	ArrayList readF;
	ArrayList trace;

	public smaliReader(File currentFile)//, String Keyword)
	{
		//Read in the file
		BufferedReader reader;
		readF = new ArrayList();
		trace = new ArrayList();
		
		try {
            reader = new BufferedReader(new FileReader(currentFile));
        
			String line = null;
			
            line = reader.readLine();
       
			while (line != null)
			{
				readF.add(line);
				
				line = reader.readLine();
				
			}
		
		} catch(IOException fnfe3) { 
				System.out.println(fnfe3.getMessage());
		}
		//pass the file to check for keyword
		//findKeyword(readF, Keyword);
		
	}
	
	public String startTrace(String keyword, int lineNumber)
	{
		String result="";
		System.out.println("Starting trace");
		
		String tmp = readF.get(lineNumber).toString();
		//System.out.println(tmp);
		
		
		int searchLine = lineNumber +1;
		String storedVar=getStoredVarible(tmp);
		//tmp = readF.get(searchLine).toString();
		while(tmp.contains(".end method")==false)
		{	
				
			if(tmp.contains(".method"))
			{
				tmp = readF.get(searchLine).toString();
				
				//System.out.println("Error: "+lineNumber);
				boolean first = true;
				while(first)
				{
					tmp = tmp.trim();
					
					if(tmp.matches(".local\\s(.*)") && first)
					{
						storedVar = getStoredVarible(tmp);
						System.out.println("Passed varible stored in "+storedVar);
						trace.add(tmp);
						first = false;
						//break;
						//
					}
					searchLine++;
					tmp = readF.get(searchLine).toString();
				}
				
			}
			else if(tmp.contains("invoke-") || tmp.contains("move-result-object") || tmp.contains("return-object"))
			{
				//storedVar = getStoredVarible(tmp);
				
				//System.out.println(keyword + " stored in "+storedVar);
				tmp = readF.get(searchLine).toString();
				String nextInstance="";
				//tmp = readF.get(searchLine).toString();
				
				
					String noReturnType = tmp.replaceAll("\\(\\S+","");
									
					if(noReturnType.contains("Lorg/apache/") || noReturnType.contains("Ljava/") || tmp.contains("move-result")||tmp.contains("return-object"))
					{
						//System.out.println("Trim: "+noReturnType);
						if( tmp.contains(storedVar) && tmp.contains("return-object"))
						{
							System.out.println("Varible is returned by method");
							result = findMethodName(lineNumber);
							result = "->"+result;
							trace.add(tmp);
							return result;
							
						}
						else if ((lineNumber + 2)==searchLine && tmp.contains("move-result"))
						{	
							storedVar = getStoredVarible(tmp);
							System.out.println("value now stored in " + storedVar);
							trace.add(tmp);
						}
						else if (tmp.contains(storedVar))
						{
							storedVar = getStoredVarible(tmp);
							System.out.println("Varible is now stored in " + storedVar);
							trace.add(tmp);
						}
					}
					else if(tmp.contains(storedVar))
					{
						//System.out.println(tmp);
						result = extractMethodName(tmp);
						result=".method(.*)"+result+"\\S+";
						trace.add(tmp);
						//result = findMethod(result);
						//System.out.println(result);
						return result;
					}
						
					
					//System.out.println(tmp);
			}
			searchLine++;
			tmp = readF.get(searchLine).toString();
		
		}
		result="End of method reached";
		return result;
	}
	
	/*public String findMethod(String methodName)
	{
		fileTraversal jill = new fileTraversal("C:\\Users\\Kanesol\\Dropbox\\Malware Samples\\smali\\");
		ArrayList files = jill.getPaths();
		
		
	
		return 
	}*/
	public String extractMethodName(String tmp)
	{
		Pattern p = Pattern.compile("(?<=->)\\S+(?=\\()");
		Matcher m = p.matcher(tmp);
		int count = 0;
		if(m.find())
		{
			tmp = tmp.substring(m.start(), m.end());
		}
		
		return tmp;
	}
	
		//what register is the method call stored in
		//System.out.println(tmp);
		
		
		/*if(varibleReturned.contains("return-object"))
		{
			result = findMethodName(lineNumber);
		}*/
		
		
	
	
	/*public findNextInstance(String storedVar, int searchLine)
	{
		for(int j=searchLine; j>readF.size(); j++)
		{
			String tmp2 = readF.get(j).toString();
			if(tmp2.contains(storedVar))
			{
			return
	}*/
	
	public String findMethodName(int lineNumber)
	{
		String found="";
		//boolean found = false;
		for(int j=lineNumber; j>0; j--)
		{
			String tmp2 = readF.get(j).toString();
			//System.out.println(tmp2);
			if(tmp2.contains("method"))
			{
				String[] methNames = tmp2.split(" ");
										
				for (String a : methNames)
				{
					if (a.contains("("))
					{
						int endMethName = a.indexOf("(");
						String methName = a.substring(0, endMethName);
						System.out.println("Method called in: "+methName);
						return methName;
						//found=true;
						//break;
						
					}
				}
				return tmp2;

			
			}
			
		}
		return found;
	}
	
	public String getStoredVarible(String tmp)
	{
		tmp = tmp.trim();
		String[] elements = tmp.split(" ");
		String a = elements[1].replace("{", "");
		a = a.replace(",", "");
		a = a.replace("}", "");
		//System.out.println("asldjf"+a);
			
		return a;
	}
	
	public String findKeyword(String keyword)
	{
		String result="";
				
		for(int i=0; i<readF.size(); i++)
		{
			
			String tmp = readF.get(i).toString();
			if(tmp.contains(keyword)|| tmp.matches(keyword) )
			{
				System.out.println(keyword+" accessed");
				trace.add(tmp);
				//
				result = startTrace(keyword, i);
				return result;
			}
		}
		return result;
	}
	
	public ArrayList getTraceLog()
	{
		return trace;
	}
	
	
	
}


